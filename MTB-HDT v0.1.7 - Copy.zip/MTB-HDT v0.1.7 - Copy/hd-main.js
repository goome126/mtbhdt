/*

hd-main.js
 - provide functions for the help desk tool
 
*/

// Form Object properties
var formProperties = [ 
	'client-name', 'client-id', 'client-loc', 'client-phone', 
	'app-name', 'app-id', 'app-url',
	'issue-users', 'issue-started',
	'dev-name', 'dev-type', 'dev-os', 'dev-w10conv', 'dev-conn', 'dev-ip',
	'client-issue', 'client-ts'
];

var formPropertiesFull = [ 
	'User Name', 'LAN ID', 'At M&T Location', 'Best Contact Number', 
	'Application', 'Application ID', 'URL',
	'Number of users affected', 'Issue started',
	'Device name', 'Device type', 'Device OS', 'Converted to W10', 'Device Connection Type',
	'Device IP Address', 'Description of Issue', 'Troubleshooting'
];

var formCheckboxes = [
	'cbVerified', 'cbUnlocked', 'cbResetPassword', 'cbResetRSAPIN', 'cbTempToken', 
	'cbRemote', 'cbOutlook', 'cbCCC', 'cbRebootVDI',
	'cbLoginSuccessful', 'cbAppLaunched', 'cbRestartResolved', 'cbVPN-SEPUpdate',
	'cbRSADistrib', 'cbTokenImport'
];

function Client() {
	for ( i in formProperties ) {
		this[formProperties[i]] = '';
	}
	
	this.clear = function() {
		for ( i in formProperties ) {
			this[formProperties[i]] = '';
		}	
	}
}

var client = new Client();

function btnParseClipboard() {
	alert( 'btnParseClipboard' );
}

function btnClearForm() {
	client.clear();
	for ( i in formProperties ) {
		setFormValue( formProperties[i], "" )
	}
	document.getElementById('client-loc').value='Y';
	document.getElementById('issue-users').value = '1';
	document.getElementById('issue-started').value = 'Today';
	document.getElementById('app-url').value = 'N/A';
	for ( i in formCheckboxes ) {
		document.getElementById(formCheckboxes[i]).checked = false;
	}
}

function btnGenNotes() {
	temp = '';
	for ( i in formProperties ) {
		if ( formProperties[i] != 'client-ts' ) {
			currentValue = getFormValue(formProperties[i])
			if ( currentValue ) {
				if ( formProperties[i] == 'client-issue') {
					temp = temp + "\n"
				}
				temp = temp + formPropertiesFull[i] + ": " + currentValue + "\n";
			}
			
			
		} else { // troubleshooting notes
			temp = temp + "Troubleshooting: ";
			if ( document.getElementById('cbVerified').checked ) {
				temp = temp + "\n- Verified user. ";
			}
			if ( document.getElementById('cbUnlocked').checked ) {
				temp = temp + "\n- Unlocked user account. "
			}
			if ( document.getElementById('cbResetPassword').checked ) {
				temp = temp + "\n- Reset password. ";
			}
			if ( document.getElementById('cbResetRSAPIN').checked ) {
				temp = temp + "\n- Reset RSA PIN. ";
			}
			if ( document.getElementById('cbTempToken').checked ) {
				temp = temp + "\n- Issued an RSA emergency access token code. ";
			}
			if ( document.getElementById('cbRSADistrib').checked ) {
				temp = temp + "\n- Redistributed RSA Token. ";
			}
			if ( document.getElementById('cbRemote').checked ) {
				temp = temp + "\n- Remote login to user PC. ";
			}
			if ( document.getElementById('cbOutlook').checked ) {
				temp = temp + "\n- Rebuilt user's Outlook profile. ";
			}
			if ( document.getElementById('cbCCC').checked ) {
				temp = temp + "\n- Performed IE troubleshooting: cleared cache and cookies, reset IE. ";
			}
			if ( document.getElementById('cbRebootVDI').checked ) {
				temp = temp + "\n- Reboot user's VDI/VPC. ";
			}
			if ( document.getElementById('cbVPN-SEPUpdate').checked ) {
				temp = temp + "\n- Walked user through SEP Live Update. ";
			}
			
			if ( getFormValue(formProperties[i]) ) {
				temp = temp +  "\n" + getFormValue(formProperties[i]);
			}
			
			if ( document.getElementById('cbTokenImport').checked ) {
				temp = temp + "\n- RSA token imported successfully into RSA SecurID application. ";
			}
			if ( document.getElementById('cbLoginSuccessful').checked ) {
				temp = temp + "\n- User signed in successfully. ";
			}
			if ( document.getElementById('cbAppLaunched').checked ) {
				temp = temp + "\n- User launched application successfully. ";
			}
			if ( document.getElementById('cbRestartResolved').checked ) {
				temp = temp + "\n- Restart resolved issue. ";
			}
		}
	}
	clipboardData.setData( 'text', temp )
}


function getFormValue( id ) {
	return document.getElementById( id ).value;
}

function setFormValue( id, inputText ) {
	document.getElementById( id ).value = inputText;
	return;
}

function btnADReset() {
	document.getElementById('client-issue').value = "MAD - Password reset"
	document.getElementById('cbVerified').checked = true
	document.getElementById('cbResetPassword').checked = true
	document.getElementById('cbLoginSuccessful').checked = true
}

function btnADUnlock() {
	document.getElementById('client-issue').value = "MAD - Account locked"
	document.getElementById('cbVerified').checked = true
	document.getElementById('cbUnlocked').checked = true
	document.getElementById('cbLoginSuccessful').checked = true
}

function btnCopyID2Clip() {
	clipboardData.setData( 'text', getFormValue('client-id') )
}

function btnCopyAppID2Clip() {
	clipboardData.setData( 'text', getFormValue('app-id') )
}

function btnCopyURL2Clip() {
	clipboardData.setData( 'text', getFormValue('app-url') )
}

function btnCopyDEV2Clip() {
	clipboardData.setData( 'text', getFormValue('dev-name') )
}

function btnCopyIP2Clip() {
	clipboardData.setData( 'text', getFormValue('dev-ip') )
}

function btnCopyID2Clip() {
	clipboardData.setData( 'text', getFormValue('client-id') )
}

function btnCopyIssue2Clip() {
	clipboardData.setData( 'text', getFormValue('client-issue') )
}


